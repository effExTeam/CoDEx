(* Wolfram Language Init File *)

Get[ "CoDEx`CoDEx`"]